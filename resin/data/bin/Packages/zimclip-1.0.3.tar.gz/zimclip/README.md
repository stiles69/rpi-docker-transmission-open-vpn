# Zim Clip

## About

Zimclip is a plugin for Zim that allows the zimclip web extension to communicate wit Zim. See the [web site](http://omacronides.com/projets/zim-clip/) for more information.

## Install

Just copy the archive content in ``~/.config/zim/plugins/``. Read [Installation](http://omacronides.com/projets/zim-clip/install/) for more information.


